I removed the git tracking from the KissFFT project because of problems with
nested git reposities.

Greetings

Kaydo
